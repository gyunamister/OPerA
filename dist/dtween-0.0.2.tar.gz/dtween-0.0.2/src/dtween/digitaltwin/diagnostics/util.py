

def equal_place(p1, p2):
    return repr(p1) == repr(p2)


# To compare OCPN-arc and PN-arc
def equal_arc(a1, a2):
    return repr(a1) == repr(a2)
