import dtween.available
import dtween.digitaltwin
import dtween.parsedata
import dtween.util


__version__ = '0.0.1'
__doc__ = "Digital Twin of an Organization realized with Action-Oriented Process Mining"
__author__ = 'Gyunam Park'
__author_email__ = 'gnpark@pads.rwth-aachen.de'
__maintainer__ = 'Gyunam Park'
__maintainer_email__ = "gnpark@pads.rwth-aachen.de"
